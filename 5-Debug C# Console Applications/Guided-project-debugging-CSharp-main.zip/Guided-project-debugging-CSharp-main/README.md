# Guided-project-debugging-CSharp
Starter and Solution code for the Guided project: "Debug and handle exceptions in a C# console application using Visual Studio Code" from the Microsoft Learn collection "Getting started with C#"
