# Challenge-project-debugging-CSharp
Starter and Solution code for the Challenge project: "Debug a C# console application using Visual Studio Code" from the Microsoft Learn collection "Getting started with C#"
